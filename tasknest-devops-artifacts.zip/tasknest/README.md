# TaskNest

A small practice web app used to demonstrate a DevOps delivery strategy:
Git flow, CI with GitHub Actions, containerisation with Docker,
local development with Docker Compose, and infrastructure as code with Terraform.

## Run locally (Python)

```bash
pip install -r requirements.txt
python app.py
```

## Run with Docker Compose

```bash
docker compose up --build
```

Then visit http://localhost:5000/ and http://localhost:5000/health

## Tests

```bash
pip install pytest pytest-cov
pytest --cov=app --cov-fail-under=60
```

## Release

Tagged release: `v1.0.0` — "First stable release: app + health endpoint"
