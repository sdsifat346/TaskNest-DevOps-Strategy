"""Unit tests for the TaskNest Flask app."""
from app import app


def client():
    app.config["TESTING"] = True
    return app.test_client()


def test_index_returns_ok():
    resp = client().get("/")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["service"] == "tasknest"
    assert data["status"] == "ok"


def test_health_endpoint_returns_200_and_healthy():
    resp = client().get("/health")
    assert resp.status_code == 200
    assert resp.get_json() == {"status": "healthy"}
