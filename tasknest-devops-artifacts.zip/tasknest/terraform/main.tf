# TaskNest - Terraform starter
# Provisions the container registry, app service and database needed
# to run the same immutable image built by CI (tagged with the commit SHA).

terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # In a real setup, state would live in a remote backend, e.g.:
  # backend "s3" {
  #   bucket = "tasknest-terraform-state"
  #   key    = "prod/terraform.tfstate"
  #   region = "eu-west-2"
  # }
}

provider "aws" {
  region = var.aws_region
}

# Container registry holding the immutable, SHA-tagged images built in CI
resource "aws_ecr_repository" "tasknest" {
  name                 = "tasknest"
  image_tag_mutability = "IMMUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}

# Application service (ECS Fargate) running the promoted image
resource "aws_ecs_cluster" "tasknest" {
  name = "tasknest-${var.environment}"
}

resource "aws_ecs_task_definition" "app" {
  family                   = "tasknest"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512

  container_definitions = jsonencode([
    {
      name  = "tasknest"
      image = "${aws_ecr_repository.tasknest.repository_url}:${var.image_tag}"
      portMappings = [
        { containerPort = 5000, protocol = "tcp" }
      ]
      environment = [
        { name = "DATABASE_URL", value = "postgres://tasknest:${var.db_password}@${aws_db_instance.tasknest.address}:5432/tasknest" },
        { name = "REDIS_URL", value = "redis://${aws_elasticache_cluster.tasknest.cache_nodes[0].address}:6379" }
      ]
      essential = true
    }
  ])
}

# Managed Postgres matching the docker-compose dev service
resource "aws_db_instance" "tasknest" {
  identifier        = "tasknest-${var.environment}"
  engine            = "postgres"
  engine_version    = "16"
  instance_class    = "db.t3.micro"
  allocated_storage = 20
  db_name           = "tasknest"
  username          = "tasknest"
  password          = var.db_password

  skip_final_snapshot = var.environment != "prod"
}

# Managed Redis matching the docker-compose dev cache
resource "aws_elasticache_cluster" "tasknest" {
  cluster_id      = "tasknest-${var.environment}"
  engine          = "redis"
  engine_version  = "7"
  node_type       = "cache.t3.micro"
  num_cache_nodes = 1
}
