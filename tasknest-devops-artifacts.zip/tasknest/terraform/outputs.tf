output "ecr_repository_url" {
  description = "Push SHA-tagged images here from CI"
  value       = aws_ecr_repository.tasknest.repository_url
}

output "ecs_cluster_name" {
  description = "Cluster the app service runs in"
  value       = aws_ecs_cluster.tasknest.name
}

output "database_endpoint" {
  description = "Postgres endpoint"
  value       = aws_db_instance.tasknest.address
}
