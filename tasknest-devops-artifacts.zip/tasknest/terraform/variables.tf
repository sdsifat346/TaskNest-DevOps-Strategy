variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "eu-west-2"
}

variable "environment" {
  description = "Deployment environment (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "image_tag" {
  description = "Docker image tag (git commit SHA) to deploy"
  type        = string
}

variable "db_password" {
  description = "Password for the Postgres database"
  type        = string
  sensitive   = true
}
